/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package tugas_praktikum9;

/**
 *
 * @author acer
 */
class Kucing extends Hewan{
    void suara(){
        System.out.println("Kucing mengeluarkan suara : Meong");
    }
}
