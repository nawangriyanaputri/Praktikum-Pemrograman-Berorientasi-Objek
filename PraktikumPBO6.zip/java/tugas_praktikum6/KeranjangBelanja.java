/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package tugas_praktikum6;
import java.util.ArrayList;

/**
 *
 * @author MSii
 */
public class KeranjangBelanja {
    private ArrayList<Produk> daftarProduk;
    
    public KeranjangBelanja(){
        daftarProduk = new ArrayList<>();
    }
    public void tambahProduk(Produk p){
        daftarProduk.add(p);
    }
    public double hitungTotalHarga(){
        double total = 0;
        for(Produk p : daftarProduk){
            total += p.hitungDiskon();
        }
        return total;
    }
    public void tampilkanProduk() {
        for (Produk p : daftarProduk) {
            System.out.println("Nama: " + p.getNama() +
                               ", Harga: " + p.getHarga() +
                               ", Setelah Diskon: " + p.hitungDiskon());
        }
    }
}