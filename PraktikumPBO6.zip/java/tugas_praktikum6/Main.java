/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package tugas_praktikum6;

/**
 *
 * @author MSii
 */
public class Main {
    public static void main(String[] args) {
        Produk buku = new Buku("Pemrograman Java", 90000);
        Produk hp = new Elektronik("Smartphone", 3000000);
        Produk baju = new Pakaian("Kaos Polos", 300000);
        
        KeranjangBelanja keranjang = new KeranjangBelanja();

        keranjang.tambahProduk(buku);
        keranjang.tambahProduk(hp);
        keranjang.tambahProduk(baju);

        System.out.println("Daftar Produk dalam Keranjang");
        keranjang.tampilkanProduk();

        double total = keranjang.hitungTotalHarga();
        System.out.println("\nTotal Harga Setelah Diskon: " + total);
    }
}