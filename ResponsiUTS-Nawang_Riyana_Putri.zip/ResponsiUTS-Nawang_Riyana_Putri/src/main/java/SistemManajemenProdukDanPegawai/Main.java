/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package SistemManajemenProdukDanPegawai;

/**
 *
 * @author MSii
 */
public class Main {
    public static void main(String[] args){
        Produk p = new Elektronik("Laptop", 15000000, 2);
        Produk p1 = new Makanan("Snack", 15000, "2025-10-06");
        
        Pegawai pegawai = new PegawaiTetap("Nawang", 5000000, 1000000);
        Pegawai pegawai1 = new PegawaiKontrak("Andi", 3000000, 12);
        
        System.out.println(" Output Produk ");
        p.tampilkanInfo();
        System.out.println();
        p1.tampilkanInfo();
        
        System.out.println("\n Output Pegawai ");
        pegawai.tampilkanInfo();
        System.out.println();
        pegawai1.tampilkanInfo();
    }
}
