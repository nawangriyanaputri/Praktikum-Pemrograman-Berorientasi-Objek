/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.responsiuts.nawang_riyana_putri;

/**
 *
 * @author MSii
 */
public class ResponsiUTSNawang_Riyana_Putri {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
