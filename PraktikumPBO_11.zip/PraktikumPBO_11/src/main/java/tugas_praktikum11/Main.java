/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package tugas_praktikum11;

/**
 *
 * @author MSii
 */
public class Main {
    public static void main(String[] args){
        Pengarang pengarang = new Pengarang("Tere Liye");
        Pengarang pengarang1 = new Pengarang("Fiersa Besari");
        
        Buku buku = new Buku("Hujan", pengarang);
        Buku buku1 = new Buku("Tapak Jejak", pengarang1);
        
        Perpustakaan perpustakaan = new Perpustakaan(3);
        perpustakaan.tambahBuku(buku);
        perpustakaan.tambahBuku(buku1);
        
        perpustakaan.infoPerpustakaan();
    }
}