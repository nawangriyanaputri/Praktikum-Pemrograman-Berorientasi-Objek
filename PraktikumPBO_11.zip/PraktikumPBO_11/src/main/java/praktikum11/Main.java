/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package praktikum11;

/**
 *
 * @author MSii
 */
public class Main {
    public static void main(String[] args){
        
        // Komposisi
        Perpustakaan perpustakaan = new Perpustakaan();
        
        Buku buku = new Buku("Hujan");
        Buku buku1 = new Buku("Laskar Pelangi");
        
        perpustakaan.tambahBuku(buku);
        perpustakaan.tambahBuku(buku1);
        
        perpustakaan.infoPerpustakaan();
        
        // Agregasi
        Anggota anggota = new Anggota("Rozan");
        Anggota anggota1 = new Anggota("Aldo");
        
        Klub klub = new Klub("Klub Futsal");
        
        klub.tambahAnggota(anggota);
        klub.tambahAnggota(anggota1);
        
        klub.infoKlub();
    }
}